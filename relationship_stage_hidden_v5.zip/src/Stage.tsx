import seed from "./assets/relationship_char.json";
import { StageBase, InitialData, Message, StageResponse } from "@chub-ai/stages-ts";

type Ledger = typeof seed;

interface InitState { seed: Ledger }
interface MessageState { ledger: Ledger }
interface ChatState {}
type ConfigType = any;

export class Stage extends StageBase<InitState, ChatState, MessageState, ConfigType> {
  constructor(data: InitialData<InitState, ChatState, MessageState, ConfigType>) {
    super(data);
  }

  async load() {
    return { initState: { seed } };
  }

  async beforePrompt(userMessage: Message): Promise<Partial<StageResponse<ChatState, MessageState>>> {
    // No special prompt injection for now
    return {};
  }

  async afterResponse(botMessage: Message): Promise<Partial<StageResponse<ChatState, MessageState>>> {
    const ledger = structuredClone(this.messageState?.ledger ?? this.initState.seed);

    if (/sword[- ]?fight|duel/i.test(botMessage.content)) {
      ledger.metrics.resentment.value += 25;
      ledger.metrics.trust.value      -= 15;
    }

    return { messageState: { ledger } };
  }

  render() { return null; }
}

export default Stage;
