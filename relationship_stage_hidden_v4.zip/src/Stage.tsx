import seed from "./assets/relationship_char.json";
import { StageBase, InitialData } from "@chub-ai/stages-ts";

type Ledger = typeof seed;
interface InitState { seed: Ledger }
interface MessageState { ledger: Ledger }
interface ChatState {}

export class Stage extends StageBase<InitState, ChatState, MessageState> {
  constructor(data: InitialData<InitState, ChatState, MessageState>) {
    super(data);
  }

  async load() {
    return { initState: { seed } };
  }

  async afterResponse({ state, botMessage }) {
    const ledger = structuredClone(state?.ledger ?? this.initState.seed);

    if (/sword[- ]?fight|duel/i.test(botMessage.content)) {
      ledger.metrics.resentment.value += 25;
      ledger.metrics.trust.value      -= 15;
    }

    return { messageState: { ledger } };
  }

  render() { return null; }
}

export default Stage;
